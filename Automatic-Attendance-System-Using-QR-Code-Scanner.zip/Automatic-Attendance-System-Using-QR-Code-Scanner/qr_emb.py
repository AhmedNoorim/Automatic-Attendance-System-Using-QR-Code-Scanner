import cv2
import numpy as np
import pyzbar.pyzbar as pyzbar
import urllib.request
import requests

font = cv2.FONT_HERSHEY_PLAIN

url_flask = "http://127.0.0.1:8001/qr"
url_qr = "http://192.168.0.118/"
cv2.namedWindow("qr scanner transmission", cv2.WINDOW_AUTOSIZE)

prev = ""
pres = ""
while True:
    img_resp = urllib.request.urlopen(url_qr + "cam-hi.jpg")
    # img_resp = urllib.request.urlopen(url_qr + "cam-hi.jpg")
    imgnp = np.array(bytearray(img_resp.read()), dtype=np.uint8)
    frame = cv2.imdecode(imgnp, -1)

    decodedObjects = pyzbar.decode(frame)
    for obj in decodedObjects:
        pres = obj.data
        if prev == pres:
            pass
        else:
            s = str(pres)
            print("Type:", obj.type)
            print("Data: ", s[2:-1])
            response = requests.post(url_flask, s)

            prev = pres
        cv2.putText(frame, str(obj.data)[2:-1], (50, 50), font, 2, (255, 0, 0), 3)

    cv2.imshow("qr scanner transmission", frame)

    key = cv2.waitKey(1)
    if key == 27:
        break

cv2.destroyAllWindows()
